// ======== FUNCIONES DE SCROLL ======== //
function scrollMenu(direction) {
  const menu = document.getElementById('menu');
  const scrollAmount = 300;
  menu.scrollBy({
    left: scrollAmount * direction,
    behavior: 'smooth'
  });
}
function scrollBebidas(direction) {
  const bebidas = document.getElementById('bebidas');
  bebidas.scrollBy({
    left: direction * 300,
    behavior: "smooth"
  });
}
function scrollPostres(direction) {
  const postres = document.getElementById('postres');
  postres.scrollBy({
    left: direction * 300,
    behavior: "smooth"
  });
}



// ======== BEBIDAS (VACÍO POR AHORA) ======== //
const bebidas = [];



// ======== PEDIDO ACTUAL DEL ALUMNO ======== //

const cartItems = document.getElementById("cart-items");
const cartTotal = document.getElementById("cart-total");
let carrito = [];

function addToCart(nombre, precio) {
    const existe = carrito.find(item => item.nombre === nombre);
    if(existe) {
        existe.cantidad++;
    } else {
        carrito.push({ nombre, precio, cantidad: 1 });
    }
    actualizarCarrito();
}

function actualizarCarrito() {
    cartItems.innerHTML = "";
    let total = 0;
    carrito.forEach(item => {
        const div = document.createElement("div");
        div.className = "cart-item";
        div.style.display = "flex";
        div.style.justifyContent = "space-between";
        div.style.borderBottom = "1px solid #ddd";
        div.style.padding = "0.3rem 0";
        div.innerHTML = `<span>${item.nombre} x${item.cantidad}</span><span>$${item.precio*item.cantidad}</span>`;
        total += item.precio*item.cantidad;
        cartItems.appendChild(div);
    });
    cartTotal.textContent = `Total: $${total}`;
}


// ==================== CONFIGURACIÓN DE PEDIDOS GUARDADOS ==================== //
const PASSWORD = "123"; // <-- cambia la contraseña si quieres
let pedidosGuardados = JSON.parse(localStorage.getItem("pedidosGuardados")) || [];

const iconoPedidos = document.getElementById("pedidos");
const modalPedidos = document.getElementById("modalPedidos");
const closeModal = document.getElementById("closeModal");
const listaPedidos = document.getElementById("listaPedidos");
 const fechaActual = new Date();
 const horaFormateada = fechaActual.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  const fechaFormateada = fechaActual.toLocaleDateString();


// Función para mostrar pedidos guardados
function mostrarPedidos() {
  listaPedidos.innerHTML = "";

  if (pedidosGuardados.length === 0) {
    listaPedidos.innerHTML = "<p style='text-align:center;'>No hay pedidos guardados.</p>";
    return;
  }

  pedidosGuardados.forEach((pedido, index) => {
    const div = document.createElement("div");
    div.className = "pedido" + (pedido.estado === "hecho" ? " hecho" : "");
    div.style.cssText = `
      border: 1px solid #ccc;
      border-radius: 8px;
      padding: 0.8rem;
      margin: 0.5rem 0;
      display: flex;
      justify-content: space-between;
      align-items: center;
      background: ${pedido.estado === "hecho" ? "lightgreen" : "#fff"};
      transition: background 0.3s;
    `;

    div.innerHTML = `
      <div>
  <strong>${pedido.nombre} ${pedido.apellido}</strong> (${pedido.grado})<br>
  <small>🛍️ ${pedido.productos.join(", ")}</small><br>
  <span style="font-size:0.8rem; color:gray;">🕒 ${pedido.hora}</span>
</div>


      <div>
        <button class="btn-hecho" data-index="${index}" style="font-size:1.2rem;">✔️</button>
        <button class="btn-eliminar" data-index="${index}" style="font-size:1.2rem;">❌</button>
      </div>
    `;
    listaPedidos.appendChild(div);
  });

  // Botones de acción
  document.querySelectorAll(".btn-hecho").forEach(btn => {
    btn.onclick = e => {
      const i = e.target.dataset.index;
      pedidosGuardados[i].estado =
        pedidosGuardados[i].estado === "hecho" ? "pendiente" : "hecho";
      localStorage.setItem("pedidosGuardados", JSON.stringify(pedidosGuardados));
      mostrarPedidos();
    };
  });

  document.querySelectorAll(".btn-eliminar").forEach(btn => {
    btn.onclick = e => {
      const i = e.target.dataset.index;
      pedidosGuardados.splice(i, 1);
      localStorage.setItem("pedidosGuardados", JSON.stringify(pedidosGuardados));
      mostrarPedidos();
    };
  });
}

// Mostrar modal con contraseña
iconoPedidos.addEventListener("click", () => {
  const pwd = prompt("🔒 Ingresa la contraseña para ver los pedidos:");
  if (pwd === PASSWORD) {
    mostrarPedidos();
    modalPedidos.style.display = "flex";
  } else if (pwd !== null) {
    alert("❌ Contraseña incorrecta");
  }
});

// Cerrar modal
closeModal.addEventListener("click", () => {
  modalPedidos.style.display = "none";
});

// ==================== GUARDAR PEDIDOS AL ENVIAR ==================== //
document.getElementById("btnEnviar").addEventListener("click", () => {
  const nombre = document.getElementById("nombre").value.trim();
  const apellido = document.getElementById("apellido").value.trim();
  const grado = document.getElementById("grado").value.trim();

  // Obtener productos del carrito
  const items = document.querySelectorAll("#cart-items div");
  if (items.length === 0) {
    alert("⚠️ No hay productos en el pedido tines que elegir uno ⚠️");
    return;
  }

  if (!nombre || !apellido || !grado) {
    alert("⚠️ Por favor llena los 3 campos ⚠️");
    return;
  }

  const productos = Array.from(items).map(i => i.querySelector("span").textContent);

   // 🕒 Agregar hora y fecha actuales
  
 

  const pedido = { 
    nombre, 
    apellido, 
    grado, 
    productos, 
    estado: "pendiente",
    hora: `${fechaFormateada} ${horaFormateada}` // 👈 se guarda fecha y hora
  };

  
  pedidosGuardados.push(pedido);
  localStorage.setItem("pedidosGuardados", JSON.stringify(pedidosGuardados));

  alert("✅ Pedido enviado correctamente✅");

  // Limpiar todo después de enviar
  document.getElementById("nombre").value = "";
  document.getElementById("apellido").value = "";
  document.getElementById("grado").value = "";
  document.getElementById("cart-items").innerHTML = "";
  document.getElementById("cart-total").textContent = "Total: $0";
});
